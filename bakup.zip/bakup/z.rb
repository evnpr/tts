
for i in 0..10
puts 'asfa'
end
